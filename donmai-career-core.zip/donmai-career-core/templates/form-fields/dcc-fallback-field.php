<div class="dcc-error-field" style="border: 2px dashed red; padding: 10px; margin: 10px 0; color: red; background: #fff0f0;">
    <strong>Configuration Error:</strong> Template file missing for field "<?php echo esc_html($key); ?>".<br>
    Please ensure the file <code>templates/form-fields/<?php echo esc_html($field['type']); ?>-field.php</code> exists.
</div>